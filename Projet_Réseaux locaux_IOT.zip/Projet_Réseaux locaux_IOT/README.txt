L'objectif de ce projet est de:
Programmer la carte B-L475E-IOT01A2 STMicroelectronics et visualisation sur un terminal les valeurs 
envoyées par les capteurs(pression humidité.)
Publier les valeurs captées vers un serveur cloud. 
Réaliser une interface graphique permet la lecture des topics MQTT.
Réaliser un dashboard permettant de suivre en temps réel les valeurs.
Ajouter une base de données pour archiver les valeurs obtenues.

Pour ce faire on a utilisé:
Arduino IDE pour la programmation
On a utilisé le broker en ligne "broker.hiemq.com" 
Node-red pour la réalisation d'une interface pour suivre la variation des valeurs
Firebase pour archiver les valeurs.

Ce travail contient une présentation ppt, une vidéo illustrative ainsi que le code de la programmation
de la carte IOT, le code json pour le node red.
 lien pour la firebase: https://console.firebase.google.com/u/0/project/projetiot-f5d67/database